import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        ValidSoduku validSoduku = new ValidSoduku();

        Scanner scanner = new Scanner(System.in);


        char[][] board = new char[9][9];

        System.out.println("Enter the 9x9 Sudoku board (one row at a time, digits 1-9 or '.' separated by spaces):");
        for (int i = 0; i < 9; i++) {
            System.out.print("Row " + (i + 1) + ": ");

            for (int j = 0; j < 9; j++) {
                if (!scanner.hasNext()) {
                    System.out.println("Invalid input! Expected 9 values per row.");
                    scanner.close();
                    return;
                }
                String token = scanner.next();

                if (token.length() != 1 || (token.charAt(0) != '.' && (token.charAt(0) < '1' || token.charAt(0) > '9'))) {
                    System.out.println("Invalid input! Use only digits 1-9 or '.'");
                    scanner.close();
                    return;
                }
                board[i][j] = token.charAt(0);
            }

            scanner.nextLine();
        }


        boolean isValid = validSoduku.Valid(board);
        System.out.println("Is the user-entered Sudoku board valid? " + isValid);


        char[][] validBoard = {
                {'5','3','.','.','7','.','.','.','.'},
                {'6','.','.','1','9','5','.','.','.'},
                {'.','9','8','.','.','.','.','6','.'},
                {'8','.','.','.','6','.','.','.','3'},
                {'4','.','.','8','.','3','.','.','1'},
                {'7','.','.','.','2','.','.','.','6'},
                {'.','6','.','.','.','.','2','8','.'},
                {'.','.','.','4','1','9','.','.','5'},
                {'.','.','.','.','8','.','.','7','9'}
        };
        System.out.println("Test Case 1 Valid Board: " + validSoduku.Valid(validBoard));



        char[][] invalidBoard = {
                {'8','3','.','.','7','.','.','.','.'},
                {'6','.','.','1','9','5','.','.','.'},
                {'.','9','8','.','.','.','.','6','.'},
                {'8','.','.','.','6','.','.','.','3'},
                {'4','.','.','8','.','3','.','.','1'},
                {'7','.','.','.','2','.','.','.','6'},
                {'.','6','.','.','.','.','2','8','.'},
                {'.','.','.','4','1','9','.','.','5'},
                {'.','.','.','.','8','.','.','7','9'}
        };
        System.out.println("Test Case Invalid Board: " + validSoduku.Valid(invalidBoard));
        scanner.close();

    }
}