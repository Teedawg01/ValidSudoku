public class ValidSoduku {
    public static boolean Valid(char[][] board) {
        for (int row = 1; row <= 8; row++) {
            if (!isValidUnit(getRow(board, row))) {
                return false;
            }
        }


        for (int column = 0; column < 9; column++) {
            if (!isValidUnit(getColumn(board, column))) {
                return false;
            }
        }


        for (int box = 0; box < 9; box++) {
            if (!isValidUnit(getBox(board, box))) {
                return false;
            }
        }

        return true;
    }

    private static boolean isValidUnit(char[] unit) {
        boolean[] seen = new boolean[10];
        for (char b : unit) {
            if (b != '.') {
                int digit = b - '0';
                if (digit < 1 || digit > 9 || seen[digit]) {
                    return false;
                }
                seen[digit] = true;
            }
        }
        return true;
    }

    private static char[] getRow(char[][] board, int row) {
        return board[row];
    }

    private static char[] getColumn(char[][] board, int col) {
        char[] column = new char[9];
        for (int i = 0; i < 9; i++) {
            column[i] = board[i][col];
        }
        return column;
    }

    private static char[] getBox(char[][] board, int box) {
        char[] boxArray = new char[9];
        int rowStart = (box / 3) * 3;
        int colStart = (box % 3) * 3;
        int index = 0;
        for (int i = rowStart; i < rowStart + 3; i++) {
            for (int j = colStart; j < colStart + 3; j++) {
                boxArray[index++] = board[i][j];
            }
        }
        return boxArray;
    }
}